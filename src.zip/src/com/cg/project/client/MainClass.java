package com.cg.project.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.beans.Associate;
import com.cg.project.beans.BankDetails;
import com.cg.project.beans.Salary;
import com.cg.project.daoservice.AssociateDAO;
import com.cg.project.daoservice.AssociateDAOImpl;

public class MainClass {

	public static void main(String[] args) {
		//EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
		//EntityManager entityManager = factory.createEntityManager();
		AssociateDAO dao = new AssociateDAOImpl();
		Associate associate = new Associate(1000, "Kajan", "Randhawa", "ADM", "SrAnalyst", "ABC123", "kajan@cg.com", new BankDetails(12345, "HDFC", "HDFC001"), new Salary(10000, 1000, 1000));
		Associate associate1 = new Associate(3000, "Sam", "Randhawa", "ADM", "SrAnalyst", "ABC123", "kajan@cg.com", new BankDetails(12345, "HDFC", "HDFC001"), new Salary(10000, 1000, 1000));
		/*Associate1 associate = new Associate1("Kajan", "Randhawa", "kajan@cg.com", "SrAnalyst");
		Associate1 associate2 = new Associate1("Sam", "Randhawa", "sam@cg.com", "SrAnalyst");
		
		associate =dao.save(associate);
		associate2 =dao.save(associate2);
		//int associateId= associate.getAssociateId();
		System.out.println("AssociateId = "+associate.getAssociateId());
		System.out.println(dao.findOne(1));
		System.out.println(dao.findOne(2));
		
		for(Associate1 findassociate : dao.findAll())
			System.out.println(findassociate);*/
		associate = dao.save(associate);
		associate1 = dao.save(associate1);
		System.out.println("AssociateId = "+associate.getAssociateID());
		System.out.println("AssociateId = "+associate1.getAssociateID());
		System.out.println(dao.findOne(1));
		System.out.println(dao.findOne(2));
		System.out.println(dao.findFewAssociate(2000));
		
		
	}

}
