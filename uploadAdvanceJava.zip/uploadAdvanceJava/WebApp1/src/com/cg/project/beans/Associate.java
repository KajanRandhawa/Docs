package com.cg.project.beans;

import java.util.Arrays;
import java.util.Date;

public class Associate {
private int associateId;
private String password;
private String firstName,lastName,department,designation,confirmPassword;
private String dob;
private String hobbies[];
public Associate(int associateId, String password) {
	super();
	this.associateId = associateId;
	this.password = password;
}

public String[] getHobbies() {
	return hobbies;
}

public void setHobbies(String[] hobbies) {
	this.hobbies = hobbies;
}

public Associate(int associateId, String password, String firstName,
		String lastName, String department, String designation,
		String confirmPassword, String dob, String[] hobbies) {
	super();
	this.associateId = associateId;
	this.password = password;
	this.firstName = firstName;
	this.lastName = lastName;
	this.department = department;
	this.designation = designation;
	this.confirmPassword = confirmPassword;
	this.dob = dob;
	this.hobbies = hobbies;
}

public Associate(int associateId, String password, String firstName,
		String lastName, String department, String designation,
		String confirmPassword, String dob) {
	super();
	this.associateId = associateId;
	this.password = password;
	this.firstName = firstName;
	this.lastName = lastName;
	this.department = department;
	this.designation = designation;
	this.confirmPassword = confirmPassword;
	this.dob = dob;
}

public Associate() {
	super();
}
public int getAssociateId() {
	return associateId;
}
public void setAssociateId(int associateId) {
	this.associateId = associateId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "Associate [associateId=" + associateId + ", password=" + password
			+ ", firstName=" + firstName + ", lastName=" + lastName
			+ ", department=" + department + ", designation=" + designation
			+ ", confirmPassword=" + confirmPassword + ", dob=" + dob
			+ ", hobbies=" + Arrays.toString(hobbies) + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + associateId;
	result = prime * result
			+ ((confirmPassword == null) ? 0 : confirmPassword.hashCode());
	result = prime * result
			+ ((department == null) ? 0 : department.hashCode());
	result = prime * result
			+ ((designation == null) ? 0 : designation.hashCode());
	result = prime * result + ((dob == null) ? 0 : dob.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + Arrays.hashCode(hobbies);
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Associate other = (Associate) obj;
	if (associateId != other.associateId)
		return false;
	if (confirmPassword == null) {
		if (other.confirmPassword != null)
			return false;
	} else if (!confirmPassword.equals(other.confirmPassword))
		return false;
	if (department == null) {
		if (other.department != null)
			return false;
	} else if (!department.equals(other.department))
		return false;
	if (designation == null) {
		if (other.designation != null)
			return false;
	} else if (!designation.equals(other.designation))
		return false;
	if (dob == null) {
		if (other.dob != null)
			return false;
	} else if (!dob.equals(other.dob))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (!Arrays.equals(hobbies, other.hobbies))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	return true;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getDepartment() {
	return department;
}

public void setDepartment(String department) {
	this.department = department;
}

public String getDesignation() {
	return designation;
}

public void setDesignation(String designation) {
	this.designation = designation;
}

public String getConfirmPassword() {
	return confirmPassword;
}

public void setConfirmPassword(String confirmPassword) {
	this.confirmPassword = confirmPassword;
}

public String getDob() {
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

}
