package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Associate;
import com.oracle.jrockit.jfr.RequestDelegate;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =response.getWriter();
		out.print("<html><body>");
		out.print("Welcome to the SignIn Page <form><table><tr><td>User Name :</td><td><input type=text name=uname /></td></tr><tr><td>Password :</td><td><input type=password name=password /></td></tr></table><input type=submit value=Submit /> <input type=reset value=Reset />");
		out.print("</body></html>");
	}*/

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int associateId=Integer.parseInt(request.getParameter("associateId"));
		String password=request.getParameter("password");
		Associate associate= new Associate(associateId,password);
		RequestDispatcher dispatcher;
		if(associate.getAssociateId()==11 && associate.getPassword().equals("abc")){
			dispatcher = request.getRequestDispatcher("loginSuccessPage.jsp");
			request.setAttribute("associate", associate);
			dispatcher.forward(request, response);
		
		}
		else{
			dispatcher = request.getRequestDispatcher("signInPage.jsp");
			request.setAttribute("errorMessage", "AssociateId or Password is incorrect");
			dispatcher.forward(request, response);
		}
		
		
		/*String associateId=request.getParameter("associateId");
		String password=request.getParameter("password");
		PrintWriter out = response.getWriter();
		out.print("<html><body><div align='center'>");
				
		if(associateId.equalsIgnoreCase("kajan")&& password.equals("abcdef")){
			out.println("<font color=green> Welcome "+associateId+"</font>");
			out.println("<br>");
			out.println("First name: "+associateId);
			out.println("Last name : Randhawa");
		}
		else
			out.print("<font color=red> Try Again </font>");
		out.print("</div></body></html>");*/
	//	super.doPost(req, resp);
	}

}
