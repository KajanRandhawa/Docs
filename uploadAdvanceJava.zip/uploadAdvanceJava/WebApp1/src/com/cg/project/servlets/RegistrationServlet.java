package com.cg.project.servlets;

import java.io.IOException;


import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Associate;


/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/Registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int associateId = Integer.parseInt(request.getParameter("associateId"));
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String department = request.getParameter("department");
		String designation = request.getParameter("designation");
		String hobbies[]=request.getParameterValues("hobbies");
		//Date date = new Date();
		//DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
		//Date dob = Date.parse(request.getParameter(dateFormat.format("dob")));
		String dob= request.getParameter("dob");
		String password = request.getParameter("password");
		String confirmPassword = request.getParameter("password2");
		
		Associate associate = new Associate(associateId, password, firstName, lastName, department, designation, confirmPassword, dob, hobbies);
		RequestDispatcher dispatcher;
		if(password.equals(confirmPassword)){
			dispatcher = request.getRequestDispatcher("registrationSuccessPage.jsp");
			request.setAttribute("associate", associate);
			dispatcher.forward(request, response);
		}
		else{
			dispatcher = request.getRequestDispatcher("registrationErrorPage.jsp");
			request.setAttribute("errorMessage", "Password entered is incorrect");
			dispatcher.forward(request, response);
		}
		
		//PrintWriter out = response.getWriter();
		/*out.print("<html><body><div align='center'>");

		if(password.equals(confirmPassword)){
			out.println("<font color=green> Welcome "+associateId+"</font>");
			out.println(" <table border =1> <tr><td>First Name : </td><td> "+firstName+"</td></tr>");
			out.println("<tr><td> Last Name :  </td><td>"+lastName+"</td></tr>");
			out.println(" <tr><td>Department : </td><td> "+department+"</td></tr>");
			out.println(" <tr><td>Designation : </td><td> "+designation+"</td></tr>");
			out.println("<tr><td>Date Of Bith: </td> <td>"+dob+"</td></tr>");
			out.print("<tr><td> Hobbies </td><td>");
			for (String h : hobbies) {
				out.println(h.toString() +" ");
			}
			out.print("</td></tr>");
		}
		else{
			out.println("<font color=red> Try again </font>");

		}
		out.print("</table></div></body></html>");*/

		/**
		 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
		 */
		/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		out.print("<html><body>");
		out.print("Welcome to the Registration Page <form><table><tr><td> Name :</td><td><input type=text name=uname /></td></tr><tr><td>Password :</td><td><input type=password name=password /></td></tr>"
				+ "<tr> <td>Confirm Password : </td><td><input type=password name = password/> </td></tr></table>"
				+ "<input type=submit value=Submit /> <input type=reset value=Reset />");
		out.print("</body></html>");
	}*/

	}
}
